SALONIN RELEASE KEYSTORE — BACKUP
==================================
Date: 2026-06-04
App: com.winnerdream.salonin

KEYSTORE FILE: salonin-release.keystore
STORE PASSWORD: 92579236ff3aaa8f6cf373fd6d513330
KEY ALIAS: 1965a7d8d8cb01a818c6342d23deb054
KEY PASSWORD: d4e31d31ee37d245e6059a4a4790e6b2

CERTIFICATE DETAILS:
- Valid from: May 26, 2026
- Valid until: Oct 11, 2053
- SHA-256: 3C:2A:7A:54:53:9A:09:F1:F9:14:89:FC:B5:E2:D9:CA:F9:85:C2:17:76:78:52:17:74:65:5F:EC:53:FD:AE:AF
- Algorithm: SHA384withRSA, 2048-bit RSA

WARNING: This keystore is required to update
the app on the Play Store. If lost, you cannot
push updates to existing users. Store securely.

KEEP THIS FILE:
- In a password manager (1Password, Bitwarden)
- In a secure cloud backup (encrypted)
- NEVER commit to git
